import { Meteor } from 'meteor/meteor';
import '../imports/api/donuts.js'

Meteor.startup(() => {
  // code to run on server at startup
});
