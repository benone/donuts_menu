import { Mongo } from 'meteor/mongo';
export const dbDonuts = new Mongo.Collection('donuts');