import React, { Component } from 'react';


export default class Donut extends Component {

}
